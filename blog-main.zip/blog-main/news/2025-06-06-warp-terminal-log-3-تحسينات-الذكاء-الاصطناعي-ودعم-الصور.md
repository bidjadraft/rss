---
layout: default
title: Warp Terminal Log 3 تحسينات الذكاء الاصطناعي ودعم الصور
image: "https://d4.alternativeto.net/2HIQaFe5_oD4EZfflLhsOcLWTe12T_huU7eHyT38xJU/rs:fill:1520:760:0/g:ce:0:0/YWJzOi8vZGlzdC9jb250ZW50LzE3NDkxNjE5MTg2OTQucG5n.png"
category: التقنية
date: 2025-06-06
---

أطلق Warp Terminal تحديث Log 3 الذي يوفر التوفر العام لخوادم Model Context Protocol (MCP) لدعم وضع الوكيل (Agent Mode) مع بيانات خارجية. يمكن للمستخدمين الآن الاتصال بخوادم MCP وإدارتها عبر علامة التبويب الجديدة في قسم Personal في Warp Drive.

يتضمن التحديث ميزات معاينة جديدة مثل دعم سياق الصورة، مما يسمح للمستخدمين بإرفاق صور مرئية مثل نماذج Figma أو مخططات معمارية لمطالبات Agent Mode. كما يتيح وضع الوكيل الآن تحسين الأوامر المقترحة وتعديل خطط التنفيذ أو اختلافات التعليمات البرمجية قبل التشغيل. بالإضافة إلى ذلك، يقدم Warp ميزة Suggested Prompts في المعاينة، مما يمكن المستخدمين من حفظ وإعادة استخدام المطالبات لمهام مثل طلبات السحب أو مراجعات التعليمات البرمجية.
