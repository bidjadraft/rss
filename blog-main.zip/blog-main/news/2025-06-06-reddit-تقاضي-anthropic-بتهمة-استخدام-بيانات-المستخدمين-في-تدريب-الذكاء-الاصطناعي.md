---
layout: default
title: Reddit تقاضي Anthropic بتهمة استخدام بيانات المستخدمين في تدريب الذكاء الاصطناعي
image: "https://d4.alternativeto.net/y2fdFZnyJtTMhkG8IXyElpzB5qudVAdsmB7QRkx377A/rs:fill:1520:760:0/g:ce:0:0/YWJzOi8vZGlzdC9jb250ZW50LzE3NDkxNjUyMjA1MDcucG5n.png"
category: التقنية
date: 2025-06-06
---

رفعت Reddit دعوى قضائية ضد Anthropic، تتهمها بجمع بيانات المستخدمين، بما في ذلك المنشورات المحذوفة، لتدريب نماذج الذكاء الاصطناعي دون موافقة المستخدمين، ما يعد خرقًا لاتفاقية المستخدم وتجاوزًا لبروتوكول robots.txt.

تزعم Reddit أن Anthropic استمرت في الوصول إلى المنصة بشكل متكرر حتى بعد إعلانها حظر ذلك، وأن هذا الاستخدام يهدد خصوصية المستخدمين، وتسعى Reddit للحصول على تعويضات وأرباح من البيانات التي تم جمعها، ومنع Anthropic من استخدام محتوى Reddit مستقبلًا.
