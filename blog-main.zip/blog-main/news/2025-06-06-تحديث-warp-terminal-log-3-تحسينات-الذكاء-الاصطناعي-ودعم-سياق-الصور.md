---
layout: default
title: تحديث Warp Terminal Log 3 تحسينات الذكاء الاصطناعي ودعم سياق الصور
image: "https://d4.alternativeto.net/2HIQaFe5_oD4EZfflLhsOcLWTe12T_huU7eHyT38xJU/rs:fill:1520:760:0/g:ce:0:0/YWJzOi8vZGlzdC9jb250ZW50LzE3NDkxNjE5MTg2OTQucG5n.png"
category: التقنية
date: 2025-06-06
---

أصدر Warp Terminal تحديث Log 3 الذي يتضمن توفرًا عامًا لخوادم Model Context Protocol (MCP) لدعم وضع الوكيل (Agent Mode) مع بيانات خارجية. يمكن للمستخدمين الآن توصيل وإدارة خوادم MCP عبر علامة تبويب جديدة في قسم Personal في Warp Drive.

يتضمن التحديث ميزات معاينة جديدة مثل دعم سياق الصور، مما يتيح للمستخدمين إرفاق صور مرئية مثل نماذج Figma أو مخططات معمارية لمطالبات Agent Mode. يدعم وضع الوكيل الآن تحسين الأوامر المقترحة وتحرير خطط التنفيذ أو اختلافات التعليمات البرمجية قبل التشغيل. يقدم Warp أيضًا مطالبات مقترحة، مما يتيح للمستخدمين حفظ وإعادة استخدام المطالبات لمهام مثل طلبات السحب أو مراجعات التعليمات البرمجية.
